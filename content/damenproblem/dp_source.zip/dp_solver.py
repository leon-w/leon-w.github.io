# -*- coding: cp1252 -*-
#=====================
# damenproblem.py
# v.02
# Python Vers.: 2.7.10
#=====================

import time

class Graph(object):   # nach Prof. Tobias H�berlein, implementiert Wun, ver�ndert L. Wiemers

    def __init__(self,n):
        self.vertices = []
        self.numNodes = n
        for i in range(0,n+1):
            self.vertices.append({})

    def addEdge(self,i,j,weight=None):
        self.vertices[i][j] = weight
        
    def nachbaren(self,i):
        return self.vertices[i].keys()




def graph_generieren(n):
    # Generiert einen Graphen mit n*n Knoten und Kanten entsprechend der Bewegungsm�glichkeiten einer Dame
    g = Graph(n*n)
    for k in range(n*n):
        k_y, k_x = (k%n)+1, int(k/n)+1
        for c in range(n*n):
            c_y, c_x = (c%n)+1, int(c/n)+1

            #  |-Vertik.-|   |-Horiz.--|   |----Diagonal--------------|
            if k_y == c_y or k_x == c_x or abs(k_x-c_x) == abs(k_y-c_y):
                g.addEdge(k+1,c+1)
    return g


def graph_zeigen(g):
    # Gibt die Nachbaren von jedem Knoten aus
    count = 0
    for i in g.vertices:
        l = len(str(g.numNodes))-len(str(count))+1
        print "("+str(count)+")"+" "*l+" |"+str(len(g.nachbaren(count)))+"|   "+str(g.nachbaren(count))
        count += 1

        
def bedroht(g, index, liste):
    # �berpr�ft, ob das Feld 'index' durch bereits gesetze Damen aus 'liste' bedroht wird
    test = []
    for i in liste:
        test.append(g.nachbaren(i))
    if index in test: return 1
    return 0


def positionen_finden(g, n, antwort, pool):
    # l�st das Damenproblem per Brute-Force-Methode
    global alle_antworten

    if pool == [] and len(antwort) == n:
        alle_antworten.append(antwort)
        return
    
    for i in pool:
        positionen_finden(g, n, antwort+[i], [item for item in pool if item not in  g.nachbaren(i)])

    return

        
def aufraeumen(liste):
    # l�scht doppelte L�sungen
    l = []
    for i in liste:
        i.sort()
        if i not in l:
            l.append(i)
    return l

def positionen_exportieren(n, liste):
    # exportiert alle L�sungen als Textdatei
    datei = open(str(n)+" Damen Positionen.txt","wb")
    for i in liste:
        print >>datei, str(i)
    datei.close()

    
def damenproblem(n):
    # initialisiert die L�sung des Damenproblems und misst die ben�tigte Zeit
    start = time.time()
    
    global alle_antworten
    alle_antworten = []
    g = graph_generieren(n)
    positionen_finden(g, n, [], range(1,n*n+1))
    alle_antworten = aufraeumen(alle_antworten)

    end = time.time()
    t = round((end-start),3)

    print str(n)+"-Damenproblem:"
    print str(len(alle_antworten))+" Loesungen in "+str(t)+"s gefunden!"
    print
    
    positionen_exportieren(n, alle_antworten)


    


if __name__ == "__main__":
    beispiel = 1
    if beispiel == 1:
        while 1:
            print "Anzahl Damen:"
            n = input()
            print
            damenproblem(int(n))
    if beispiel == 2:
        g = graph_generieren(8)
        graph_zeigen(g)



"""

 1  2  3  4  5  6  7  8
 9 10 11 12 13 14 15 16
17 18 19 20 21 22 23 24
25 26 27 28 29 30 31 32
33 34 35 36 37 38 39 40
41 42 43 44 45 46 47 48
49 50 51 52 53 54 55 56
57 58 59 60 61 62 63 64

"""
        
       
        



