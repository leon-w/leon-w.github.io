import sys, os, ttk, tkMessageBox
from Tkinter import *
from tkFileDialog import *
from tkColorChooser import askcolor 
from PIL import Image, ImageSequence


b_font_13 = ("Helvetica",13, "bold")
b_font_10 = ("Helvetica",10, "bold")
font_10 = ("Helvetica",10)

options = ["White", "Black", "Transparent", "Custom..."]

text = """
GIF frame extraction by mmgp.\n
www.stackoverflow.com/users/1832154/mmgp\n
Post: www.stackoverflow.com/questions/14550055/loss-of-data-when-extracting-frames-from-gif-to-png\n
Program, GUI: Leon W.
"""

class Main_gui:
    
    def __init__(self,master):
        self.master = master
        self.master.resizable(0,0)
        

        self.color = StringVar()
        self.status = StringVar()
        self.x_prop = IntVar()
        self.y_prop = IntVar()
        self.nframe = IntVar()
        self.scale = IntVar()
        self.scale.set(100)
        self.color.set("Transparent")
        self.status.set("Waiting for export...")
        self.scale.trace("w", lambda *pargs: self.update("scale"))
        self.x_prop.trace("w", lambda *pargs: self.update("x"))
        self.y_prop.trace("w", lambda *pargs: self.update("y"))
        self.nframe.trace("w", lambda *pargs: self.update("nframe"))
        self.color.trace("w", lambda *pargs: self.update("color"))

        self.pre_border = 0
        self.pre_bg_color = "#F0F0F0"
        self.pre_square_color = "#000000"
        self.path = ""
        

   
        # GUI

        self.master.title("GIF to stripe")
        
        # Import and Scale
            
        self.labelframe_import = LabelFrame(self.master, text="Import and Scale",highlightthickness=4,bd=2,padx=8,pady=8,font=b_font_13)
        self.labelframe_import.pack(fill="both", expand="yes")

        self.label_x = Label(self.labelframe_import, text="Height:", font=b_font_10)
        self.label_x.grid(row=0, column=0, sticky=W)

        self.label_y = Label(self.labelframe_import, text="Width:", font=b_font_10)
        self.label_y.grid(row=1, column=0, sticky=W)

        self.label_frames = Label(self.labelframe_import, text="Lenght:", font=b_font_10)
        self.label_frames.grid(row=2, column=0, sticky=W)

        self.label_x_value = Label(self.labelframe_import, text="0", font=font_10)
        self.label_x_value.grid(row=0, column=1, sticky=W, padx=20)

        self.label_y_value = Label(self.labelframe_import, text="0", font=font_10)
        self.label_y_value.grid(row=1, column=1, sticky=W, padx=20)

        self.label_frames_value = Label(self.labelframe_import, text="0", font=font_10)
        self.label_frames_value.grid(row=2, column=1, sticky=W, padx=20)

        self.label_scale = Label(self.labelframe_import, text="Scale % :", font=b_font_10)
        self.label_scale.grid(row=0, column=3, sticky=W, padx=10)

        self.label_nframe = Label(self.labelframe_import, text="Used Frames:", font=b_font_10)
        self.label_nframe.grid(row=2, column=3, sticky=W, padx=10)
 
        self.spinbox_scale = Spinbox(self.labelframe_import, from_=1, to=200, textvariable=self.scale, width=10)
        self.spinbox_scale.grid(row=0, column=4, sticky=W, padx=(10,100))

        self.label_scale_pixel = Label(self.labelframe_import, text="0 x 0 Pixel", font=font_10)
        self.label_scale_pixel.grid(row=1, column=3, sticky=W, padx=20)
        
        self.spinbox_nframe = Spinbox(self.labelframe_import, textvariable=self.nframe, from_=1, to=1, width=10)
        self.spinbox_nframe.grid(row=2, column=4, sticky=W, padx=(10,100))

        self.seperator_1 = ttk.Separator(self.labelframe_import, orient=VERTICAL)
        self.seperator_1.grid(row=0, column=2, sticky=N+S, rowspan=3)

        self.button_select = Button(self.labelframe_import, text="Select File...", command=self.select_file, font=b_font_10)
        self.button_select.grid(row=3, column=0, sticky=W+E+S, columnspan=5, pady= 5)

        # Proportion
        
        self.labelframe_proportion = LabelFrame(self.master, text="Proportion and BG",highlightthickness=4,bd=2,padx=8,pady=8,font=b_font_13)
        self.labelframe_proportion.pack(fill="both", expand="yes")

        self.label_x2 = Label(self.labelframe_proportion, text="X:", font=b_font_10)
        self.label_x2.grid(row=0, column=0, sticky=W+N)

        self.label_y2 = Label(self.labelframe_proportion, text="Y:", font=b_font_10)
        self.label_y2.grid(row=1, column=0, sticky=W+N)

        self.spinbox_x = Spinbox(self.labelframe_proportion, textvariable=self.x_prop, from_=1, to=1, width=10)
        self.spinbox_x.grid(row=0, column=1, sticky=W+N, padx=10)

        self.spinbox_y = Spinbox(self.labelframe_proportion, textvariable=self.y_prop, from_=1, to=1, width=10)
        self.spinbox_y.grid(row=1, column=1, sticky=W+N, padx=10)

        self.button_switch = Button(self.labelframe_proportion, text="Switch", command=self.switch, font=b_font_10)
        self.button_switch.grid(row=2, column=0, sticky=W+E+N, columnspan=2, pady= 5)

        self.button_best = Button(self.labelframe_proportion, text="Best", command=self.best, font=b_font_10)
        self.button_best.grid(row=3, column=0, sticky=W+E+N, columnspan=2)

        self.label_pre = Label(self.labelframe_proportion, text="Preview:", font=font_10)
        self.label_pre.grid(row=0, column=3, sticky=W+N)

        self.canvas_preview = Canvas(self.labelframe_proportion, height=180, width=180)
        self.canvas_preview.grid(row=1, column=3,rowspan=5)

        self.seperator_2 = ttk.Separator(self.labelframe_proportion, orient=VERTICAL)
        self.seperator_2.grid(row=0, column=2, sticky=N+S, rowspan=5, padx=15)

        self.label_bg = Label(self.labelframe_proportion, text="BG:", font=b_font_10)
        self.label_bg.grid(row=4, column=0, sticky=W)
 
        self.optionmenu_color = OptionMenu(self.labelframe_proportion, self.color, *options)
        self.optionmenu_color.grid(row=4, column=1, sticky=W+E)

        # Export

        self.labelframe_export = LabelFrame(self.master, text="Export",highlightthickness=4,bd=2,padx=8,pady=8,font=b_font_13)
        self.labelframe_export.pack(fill="both", expand="yes")

        self.label_status = Label(self.labelframe_export, textvariable=self.status, font=font_10)
        self.label_status.pack(fill="both", expand="yes", side=BOTTOM,)

        self.progress = ttk.Progressbar(self.labelframe_export, orient="horizontal",length=400, mode="determinate", maximum=300)
        self.progress.pack(fill="both", expand="yes", side=BOTTOM, pady=5, padx=5)
        
        self.button_about = Button(self.labelframe_export, text="About...", command=self.about, font=b_font_10)
        self.button_about.pack(fill="both", expand="yes", side=LEFT, pady=5, padx=5)

        self.button_exit = Button(self.labelframe_export, text="Exit", command=self.__del__, font=b_font_10)
        self.button_exit.pack(fill="both", expand="yes", side=LEFT, pady=5, padx=5)

        self.button_export = Button(self.labelframe_export, text="Export...", command=self.export, font=b_font_10)
        self.button_export.pack(fill="both", expand="yes", side=LEFT, pady=5, padx=5)

    def __del__(self):
        self.master.destroy()
        try: self.r.destroy()
        except: pass

    def select_file(self):

        def get_gif_info(gif):
            counter = 0
            try:
                while 1:
                    gif.seek(counter)
                    counter += 1
            except: pass
            x, y = gif.size
            return {"x":x, "y":y, "frames":counter}
    
        p = askopenfilename(parent=self.master, filetypes = [("Animated GIFs","*.gif")],title="Select GIF")

        if len(p) != 0:
            self.path = p
            try:
                self.img = Image.open(self.path)
                self.img_info = get_gif_info(self.img)
                self.label_x_value.configure(text="%d Pixels" % self.img_info["x"])
                self.label_y_value.configure(text="%d Pixels" % self.img_info["y"])
                self.label_frames_value.configure(text="%d Frames" % self.img_info["frames"])
                self.labelframe_import.configure(text="Import and Scale: "+os.path.basename(self.path))
                self.nframe.set(self.img_info["frames"])
                self.spinbox_nframe.configure(to=self.img_info["frames"])
                self.spinbox_x.configure(to=self.img_info["frames"])
                self.spinbox_y.configure(to=self.img_info["frames"])
                self.best()
            except: pass

                
    def update(self, source):
        if self.path:
            if source == "color": # update from bg
                c = self.color.get()
                if c == "White":
                    self.pre_border = 0
                    self.pre_bg_color = "#FFFFFF"
                    self.pre_square_color = "#000000"
                elif c == "Black":
                    self.pre_border = 0
                    self.pre_bg_color = "#000000"
                    self.pre_square_color = "#FFFFFF"
                elif c == "Transparent":
                    self.pre_border = 0
                    self.pre_bg_color = "#F0F0F0"
                    self.pre_square_color = "#000000"
                else:
                    self.pre_border = 1
                    self.pre_bg_color = askcolor()[1]
                    self.pre_square_color = "#FFFFFF"
                self.draw_preview()
            elif source == "x": # update from x prop
                try:
                    if not self.x_prop.get()*self.y_prop.get() is self.nframe.get():
                        if self.nframe.get()/self.x_prop.get() == float(self.nframe.get())/self.x_prop.get():
                           self.y_prop.set(self.nframe.get()/self.x_prop.get())
                        else:
                            self.y_prop.set(0)
                        self.update("scale")
                        self.draw_preview()
                except: pass
            elif source == "y": # update from y prop
                try:
                    if not self.x_prop.get()*self.y_prop.get() is self.nframe.get():
                        if self.nframe.get()/self.y_prop.get() == float(self.nframe.get())/self.y_prop.get():
                           self.x_prop.set(self.nframe.get()/self.y_prop.get())
                        else:
                            self.x_prop.set(0)
                        self.update("scale")
                        self.draw_preview()
                except: pass
            elif source == "nframe": # update from used frames
                self.spinbox_x.configure(to=self.nframe.get())
                self.spinbox_y.configure(to=self.nframe.get())
                self.best()
            elif source == "scale": # update from scale
                try:
                    s = (self.img_info["x"]*self.scale.get()/100.0, self.img_info["y"]*self.scale.get()/100.0)
                    self.label_scale_pixel.configure(text= "%d x %d Pixel (%d x %d)" % (s[0],s[1],s[0]*self.x_prop.get(),s[1]*self.y_prop.get()))
                except: pass
    

    def switch(self):
        try:
            tmp = self.x_prop.get()
            self.x_prop.set(self.y_prop.get())
            self.y_prop.set(tmp)
        except: pass


    def best(self):
        try:
            total = self.nframe.get()
            last = 1
            for i in range(1,((total+1)/2+1)):
                if float(total)/i == total/i:
                    if (i+(total/i)) < (last+(total/last)):
                        last = i
            self.x_prop.set(last)
            self.y_prop.set(total/last)
            self.update("scale")
        except: pass
        

    def draw_preview(self):
        try:
            x = self.x_prop.get()
            y = self.y_prop.get()
            if 160/x < 160/y:
                s = 160/x
            else:
                s= 160/y
            if s < 3:
                s = 3
            x_offset = (180-(s*x))/2
            y_offset = (180-(s*y))/2
            self.canvas_preview.delete("pre")
            self.canvas_preview.configure(bg=self.pre_bg_color)
            for i in range(x):
                for j in range(y):
                    self.canvas_preview.create_rectangle(s*i+2+x_offset,s*j+2+y_offset,s*i+s+x_offset,s*j+s+y_offset, fill=self.pre_square_color, tag="pre", width=self.pre_border, outline="black")
        except: pass


    def about(self):
        self.r = Tk()
        self.about = About_window(self.r)
        self.r.mainloop()

    def progress_update(self, value):
        if value == 0:
            self.status.set("Waiting for export...")
        self.progress.configure(value=value)
        self.master.update()

    def export(self):
        
        def reduce_frames(array):
            rem = self.img_info["frames"] -self.nframe.get()
            if not rem <= 0:
                while rem >= len(array)/2:
                    counter = 0
                    for i in range(0, len(array),2):
                        del array[i-counter]
                        counter += 1
                    rem = len(array)-self.nframe.get()
                space = len(array)/rem
                counter = 0
                for i in range(0, len(array), space):
                    if len(array) > self.nframe.get():
                        del array[i-counter]
                        counter += 1
            return array

        def scale_frames(array):
            if self.scale.get() != 100:
                scaled_frames = []
                w = int(self.img_info["x"]*(self.scale.get()/100.0))
                h = int(self.img_info["y"]*(self.scale.get()/100.0))
                for i in array:
                    tmp = i.resize((w, h), Image.ANTIALIAS)
                    scaled_frames.append(tmp)
                    self.progress_update((((array.index(i)+1)/float(len(array))))*150) #progress
                return scaled_frames
            else: return array

        def combine_frames(array):
            w = int(self.img_info["x"]*(self.scale.get()/100.0))
            h = int(self.img_info["y"]*(self.scale.get()/100.0))
            new_im = Image.new("RGBA", (w*self.x_prop.get(),h*self.y_prop.get()))
            if not self.color.get() == "Transparent":
                new_im.paste(self.pre_bg_color,[0,0,new_im.size[0],new_im.size[1]])
            for y_ in range(self.y_prop.get()):
                for x_ in range(self.x_prop.get()):
                    new_im.paste(array[y_*self.x_prop.get()+x_],(x_*w,y_*h),mask=array[y_*self.x_prop.get()+x_])
                    self.progress_update(((y_*self.x_prop.get()+x_+1.0)/len(array))*100+150)
            return new_im

        if not self.path:
            tkMessageBox.showerror("No GIF selected", "Please select a GIF befor exporting!")
            return

        if self.y_prop.get() == 0 or self.x_prop.get() == 0:
            tkMessageBox.showerror("Wrong Proportion", "Please select a valid proportion befor exporting!")
            return
        
        x_total = self.img_info["x"]*(self.scale.get()/100.0)*self.x_prop.get()
        y_total = self.img_info["y"]*(self.scale.get()/100.0)*self.y_prop.get()
        l = min((8192/(self.img_info["x"]*self.x_prop.get()*1.0)*100),(8192/(self.img_info["y"]*self.y_prop.get()*1.0)*100))
        if x_total > 8192 or y_total > 8192:
            if not tkMessageBox.askyesno("Large image warning", "The image is to big for UE4. \n Continue? \n (Try Scale %d or lower)" % l):
                return
            else: pass
            
        f = asksaveasfilename(filetypes=[("Image Files","*.png")])
        if f != "":
            self.src_img = Image.open(self.path)

            frames = reduce_frames(split_gif(self.src_img))

            self.status.set("Scaling Frames...")
            self.master.update()
            frames = scale_frames(frames)

            self.status.set("Combining Frames...")
            self.master.update()
            result = combine_frames(frames)

            self.status.set("Saving File...")
            self.master.update()

            if f[-4:] != ".png":
                f = f+" (%dx%d)" % (self.x_prop.get(),self.y_prop.get())+".png"
            else:
                f = f[:-4]+" (%dx%d)" % (self.x_prop.get(),dself.y_prop.get())+".png"

            result.save(f)
            
            self.progress_update(300)

            self.status.set("Done!")

            self.progress.after(2000, lambda: self.progress_update(0))


            
            


class About_window():
    def __init__(self, master):
        self.master = master

        self.master.resizable(0,0)
        self.master.title("About")
        
        self.label = Message(self.master, text=text, relief=RAISED)
        self.label.pack(fill="both", expand="yes", padx=10, pady=10)

        self.button_close = Button(self.master, text="Close", command=self.master.destroy, font=b_font_10)
        self.button_close.pack(fill="both", expand="yes", side=LEFT, pady=10, padx=10)
        

def split_gif(gif): # from http://stackoverflow.com/questions/14550055/loss-of-data-when-extracting-frames-from-gif-to-png (modiefied) 
    frames = []
    pal = gif.getpalette()
    prev = gif.convert('RGBA')
    prev_dispose = True
    for i, frame in enumerate(ImageSequence.Iterator(gif)):
        dispose = frame.dispose
        if frame.tile:
            x0, y0, x1, y1 = frame.tile[0][1]
            if not frame.palette.dirty:
                frame.putpalette(pal)
            frame = frame.crop((x0, y0, x1, y1))
            bbox = (x0, y0, x1, y1)
        else:
            bbox = None
        if dispose is None:
            prev.paste(frame, bbox, frame.convert('RGBA'))
            frames.append(prev.copy())
            prev_dispose = False
        else:
            if prev_dispose:
                prev = Image.new('RGBA', gif.size, (0, 0, 0, 0))
            out = prev.copy()
            out.paste(frame, bbox, frame.convert('RGBA'))
            frames.append(out.copy())
    return frames

def main():
    root = Tk()
    app = Main_gui(root)
    root.mainloop()


if __name__ == "__main__":
    main()
