#---------------------------
# app.py v1 (Py 3.5)
#---------------------------

import main_gui

if __name__ == "__main__":
	app = main_gui.IsbnApp(None)
	app.mainloop()
