#---------------------------
# datagrabber.py v2 (Py 3.5)
#---------------------------

import os
import re
import urllib.request
import ssl
import time
from PIL import Image


def grabdata(isbn):  # returns a dictionary with title, publisher, time and status + places cover in saved folder

    time_a = time.time()

    url = "https://portal.dnb.de/opac.htm?method=showFullRecord&currentResultId="+str(isbn)+"%26any&currentPosition=0"
    data = {}

    try:
        request = urllib.request.urlopen(url, context=ssl._create_unverified_context())
        requestdata = request.read().decode('utf-8').replace(u"\n", '').replace(u"\r", '').replace(u"\t", '')
        internet = 1
    except:
        data["status"] = (1,"No network")
        internet = 0

    if internet:
        amount = re.findall(r'<span class="amount">(.*?)</span>',requestdata)
        if not amount: amount = 0
        else: amount = int(list(amount[0])[-1])

        try:
            if amount >= 1:
                data["publisher"] = re.findall(r"<strong>Verlag</strong></td>(.*?)</td>",requestdata)[0].split('>')[-1].strip()
                title = re.findall(r"<strong>Titel</strong></td>(.*?)</td>",requestdata)[0].replace("</td>","").replace("</a>","").replace("<br/>"," ").split(">")[-1].strip()
                data["title"] = title
                data["status"] = (0, "Ok")
            else:
                data["status"] = (1, "No results")
        except:
            data["status"] = (1, "Problem with parsing data")

    data["image"] = getimage("https://portal.dnb.de/opac/mvb/cover.htm?isbn="+str(isbn)+"&size=m", isbn)
    data["isbn"] = isbn

    time_b = time.time()
    time_c = time_b - time_a
    data["time"] = round(float(time_c), 2)

    return data


def getimage(link, isbn):
    try:
        if not os.path.exists("saved"):
            os.makedirs("saved")
        urllib.request.urlretrieve(link, "tmp.jpg")
        Image.open("tmp.jpg").save("saved\\"+str(isbn)+".gif")
        os.remove("tmp.jpg")
        return True
    except:
        return False


if __name__ == "__main__":
    dic = grabdata(example_isbn1)
    print(dic)
    try:
        getimage(dic["img_link"],example_isbn1)
    except: pass
