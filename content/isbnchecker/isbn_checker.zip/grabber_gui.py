#---------------------------
# grabber_gui.py v1 (Py 3.5)
#---------------------------

from tkinter import *
from tkinter import ttk,messagebox
import datagrabber2
import threading
import isbnchecker


f = ("Helvetica", 10, "bold")
f_mono = ("Consolas",13, "bold")


class DatagrabberGui(Toplevel):

    def __init__(self, parent,title, isbn):
        Toplevel.__init__(self, parent)
        self.parent = parent

        self.buisy = 0
        self.isbn = isbn

        self.protocol("WM_DELETE_WINDOW", self.exit)

        self.title(title+": "+str(isbn))
        self.focus_force()
        self.bind("<Escape>", lambda i: self.exit())

        self.frame = Frame(self, padx=8, pady=8)
        self.frame.pack(fill=BOTH, expand=1)

        self.labelframe = LabelFrame(self.frame, text=title+": "+str(isbn), padx=8, pady=8, font=f)
        self.labelframe.pack(fill=BOTH, expand=1)

        self.frame_len_publisher = Frame(self.labelframe)
        self.frame_len_publisher.pack(fill=BOTH,expand=1)

        self.frame_content = Frame(self.labelframe)
        self.frame_content.pack(fill=X)

        self.frame_buttons = Frame(self.labelframe)
        self.frame_buttons.pack(fill=X)

        # widgets

        self.len = Label(self.frame_len_publisher, text="Länge der Gruppennummer: ")
        self.len.pack(side=LEFT)

        self.len_spin = Spinbox(self.frame_len_publisher,from_=1, to=5, font=f_mono)
        self.len_spin.pack(side=LEFT, expand=1, fill=X)

        self.loading = ttk.Progressbar(self.frame_content, orient="horizontal")
        self.loading.pack(fill=X,pady=15)

        self.button_start = Button(self.frame_buttons, text="Daten anfordern", bg="lightgray", font=f, command=self.get_data)
        self.button_start.pack(fill=X, side=LEFT, expand=1, padx=(0,15))

        self.button_destroy = Button(self.frame_buttons, text="Fesnter schließen", command=self.exit, bg="lightgray",font=f)
        self.button_destroy.pack(fill=X, side=LEFT, expand=1)

    def loading_anim(self, mode):
        if mode:
            self.loading["mode"]="indeterminate"
            self.loading.start(10)
        else:
            self.loading.stop()
            self.loading["mode"] = "determinate"
            self.loading["value"] = 0

    def get_data(self):

        def receive():
            self.data = datagrabber2.grabdata(self.isbn)
            self.loading_anim(0)
            self.buisy = 0
            data_done()

        def data_done():
            if self.data["status"][0]:
                message_text="Es konnten keine Daten geladen werden.\nGrund: "+self.data["status"][1]
                icon = "error"
            else:
                if self.data["image"]: bild_stat= "(Mit Bild)"
                else: bild_stat = "(Kein Bild)"
                message_text = "Daten wurden erfolgreich geladen. "+bild_stat
                icon = "info"
                self.generate_file(self.data)

            messagebox.showinfo("Fertig in "+str(self.data["time"])+" Sekunden",message_text, icon=icon)
            self.exit()
            self.parent.selection_handler()

        try:
            int(self.len_spin.get())
        except:
            messagebox.showerror("Eingabefehler","Eingabe ist keine Zahl!")
            return

        self.buisy = 1
        self.loading_anim(1)

        t = threading.Thread(target=receive)
        t.start()

    def generate_file(self,data):
        v = int(self.len_spin.get())
        x = str(data["isbn"])[3:(3+v)]
        c = isbnchecker.getcountry(x)

        with open(str("saved\\" + data["isbn"]) + ".txt", "w") as f:
            text = ['"isbn":' + str(data["isbn"]) + '\n',
                    '"image":' + str(data["image"]) + '\n',
                    '"title":"' + str(data["title"]) + '"\n',
                    '"publisher":"' + str(data["publisher"]) + '"\n',
                    '"country":"' + c + '"\n']
            f.writelines(text)

    def exit(self):
        if not self.buisy:
            self.loading.stop()
            self.destroy()



