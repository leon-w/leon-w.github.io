#---------------------------
# isbnchecker.py v1 (Py 3.5)
#---------------------------


"""
             Land     Titelnummer
              |            |
              |            |
ISBN    978 - 3 - 86680 - 192 - 9
         |           |          |
         |           |          |
      Präfix      Verlag    Prüfziffer

"""


def prepisbn(isbn):

    def remove_dash(raw):
        new_isbn = ""
        for i in str(isbn).split("-"):
            new_isbn += i
        try:
            int(new_isbn)
            return new_isbn
        except: return

    if len(str(isbn)) in [17, 13]:
        isbn = remove_dash(isbn)
    if len(str(isbn)) in [13, 10]:
        try: int(isbn)
        except: return
        if len(str(isbn))== 10:
            isbn = int("978"+str(isbn))
        if len(str(isbn)) == 13:
            return int(isbn)
    else: return


def checkisbn(isbn):

    count = 0
    m = 1
    for i in list(str(isbn)[:-1]):
        count += int(i)*m
        if m == 1: m = 3
        else: m = 1
    checker = (10 - (count % 10)) % 10

    if checker == isbn % 10:
        return True
    else:
        return False


def getcountry(number):
    from countrydb import db
    for line in db:
        num = line.split(" ")[0] 
        name = line.split(" ")[1]
        if int(number) == int(num):
            return name
    return "Cant get country name (not in database)"


def moreinfo(isbn):
    p1="""
     %d  %d  %d  %d  %d  %d  %d  %d  %d  %d  %d  %d  ?
     |  |  |  |  |  |  |  |  |  |  |  |
     *1 *3 *1 *3 *1 *3 *1 *3 *1 *3 *1 *3
     |  |  |  |  |  |  |  |  |  |  |  | """
    p2="""
    {:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2}+{:2} = {:0}
    """
    p3="""
    Abstand zum nächsthöheren Vielfachen von 10:
    {}

    Berechnete Prüfziffer: {}
    Gegebene   Prüfziffer: {}

    ISBN ist {}.
    """

    v1 = [int(i) for i in str(isbn)][:-1]
    c, m, v2 = 1,1, []
    for i in v1:
        if c % 2 == 0: m = 3
        else: m = 1
        v2.append(i*m)
        c += 1

    z1 = sum(v2)
    z2 = z1+((10-(z1 % 10)) % 10)
    diff = z2-z1

    if diff == int(str(isbn)[-1]): e = "gültig"
    else: e = "ungültig"

    v3 = [str(z2)+" - "+str(z1)+" = "+str(diff), diff, str(isbn)[-1], e]

    v2.append(sum(v2))
    text = (p1%tuple(v1))+(p2.format(*tuple(v2)))+(p3.format(*tuple(v3)))
    text2 = text.replace("|","↓")
    return text2
























