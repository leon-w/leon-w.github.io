#---------------------------
# main_gui.py v1 (Py 3.5)
#---------------------------

from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter import messagebox
import small_gui
import isbnchecker
import grabber_gui
import shutil
import os


#Fonts:
f_b1 = ("Helvetica",13, "bold")
f_b2 = ("Helvetica",10, "bold")
f_1 = ("Helvetica",13)
f_2 = ("Helvetica",10)
f_mono1 = ("Consolas",13, "bold")

#Colors
c_accent = "lightgray"

#Strings
about_text = """
Von Leon W.
Bilder und Daten bereitgestellt durch portal.dnb.de
(Deutsche Nationalbibliothek)
"""

help_text = """
Unterschtützte Eingabeformate:

XXX-X-XXXXX-XXX-X
XXXXXXXXXXXXX
X-XXXXX-XXX-X
XXXXXXXXXX

Verhältnisse zwischen den Gruppen können variieren.

"""


class IsbnApp(Tk):

    def __init__(self, parent):
        Tk.__init__(self, parent)
        self.parent = parent
        self.initialize()

    def initialize(self):
        self.title("ISBN Checker")

        self.bind("e", lambda i: self.load_examples())
        self.protocol("WM_DELETE_WINDOW", self.leave_program)

        # Variables

        self.isbn = StringVar()

        # Frames

        self.frame = Frame(self, padx=8, pady=8)
        self.frame.pack(fill=BOTH, expand=1)

        self.labelframe_left = LabelFrame(self.frame, text="ISBN Checker", padx=8, pady=8, bd=3, font=f_b2)
        self.labelframe_left.pack(fill=BOTH, side=LEFT, padx=(0,4))

        self.labelframe_right = LabelFrame(self.frame, text="Details", padx=8, pady=8, bd=3, font=f_b2)
        self.labelframe_right.pack(fill=BOTH, expand=1, side=RIGHT, padx=(4,0))

        self.frame_input = Frame(self.labelframe_left)
        self.frame_input.pack(fill=X, anchor=N)

        self.frame_list = Frame(self.labelframe_left)
        self.frame_list.pack(fill=BOTH, pady=8, expand=1)

        self.frame_buttons = Frame(self.labelframe_left)
        self.frame_buttons.pack(fill=X, anchor=S)

        self.frame_details = Frame(self.labelframe_right)
        self.frame_details.pack(fill=BOTH, expand=1)

        self.frame_details_buttons = Frame(self.labelframe_right)
        self.frame_details_buttons.pack(fill=X, anchor=S)

        # Frame isbn input

        self.label_isbn = Label(self.frame_input, text="ISBN:", font=f_b1)
        self.label_isbn.pack(pady=(2, 2),side=LEFT)

        self.entry_isbn = Entry(self.frame_input, font=f_mono1, textvariable=self.isbn)
        self.entry_isbn.bind("<Return>", lambda i: self.btn_callback("isbn_new"))
        self.entry_isbn.pack(fill=X, expand=1, padx=15,side=LEFT)

        self.button_enter = Button(self.frame_input, text="Prüfen", font=f_b2, bg=c_accent, command=lambda : self.btn_callback("isbn_new"))
        self.button_enter.pack(side=LEFT)

        # Frame isbn list

        self.list_isbn = Listbox(self.frame_list, selectmode=SINGLE, height=16, font=f_1, )
        self.list_isbn.bind("<<ListboxSelect>>", lambda i: self.btn_callback("list"))
        self.list_isbn.bind("<Double-Button-1>", lambda i: self.btn_callback("more"))
        self.list_isbn.pack(fill=BOTH, expand=1, side=LEFT)

        self.scroll_list_isbn = Scrollbar(self.frame_list, command=self.list_isbn.yview)
        self.scroll_list_isbn.pack(fill=Y,side=LEFT, anchor=E)

        self.list_isbn.configure(yscrollcommand=self.scroll_list_isbn.set)

        # Frame isbn buttons

        self.button_del = Button(self.frame_buttons, text="Löschen", font=f_b2, bg=c_accent, command=lambda: self.btn_callback("del"), state=DISABLED)
        self.button_del.pack(side=LEFT, fill=X, expand=1)

        self.button_about = Button(self.frame_buttons, text="Über...", font=f_b2, bg=c_accent, command=lambda: self.btn_callback("about"))
        self.button_about.pack(side=LEFT, fill=X, expand=1, padx=15)

        self.button_exit = Button(self.frame_buttons, text="Beenden", font=f_b2, bg=c_accent, command=lambda: self.btn_callback("exit"))
        self.button_exit.pack(side=LEFT, fill=X, expand=1)

        # Frame details

        self.label_titel = Message(self.frame_details, text="Kein Titel verfügbar", font=("Helvetica",16, "bold"), anchor=CENTER)
        self.label_titel.bind("<Configure>", lambda e: self.label_titel.configure(width=e.width - 10))
        self.label_titel.pack(fill=X,anchor=N)

        img_data = "R0lGODlhyAAnAecAAAECBAILBgEGCgIKDAsICRYFBwIMEgUNFgoTFRAUESQCAjQMCwEUJQ0WJAsoMy0vMSEkGE0vF1Y6KEs4L2QiECdPLllEOFFDNGtMN2ZzMzw0WzIyTTk2Zis7eDM7ezY6dis2ahAxVkU1WkM2ZEE+cXI4SjhJSxZVdDdDeSxNdiJiaFFPTmtXTHNlVk1Nb1RobW9ublhmYIgvOa8tM5UqEqZUL85ZNIcwQrkuRMkyS5BuVYp5baRlU9NvU8YxKyqaaFyeZl+fTJOGd62MdaOfXeKWXsyoUjM9giw9hxQ8gRhYiQtanQdZmRRVnRtVnBZZlxFQjSpHiTNFhydZiitLlCpNmyhKljNJliRSnShWlzRXmTZYiQhkmxllmRJxlSVoiyVmmCdzlTVrkgRdpAtaowNdqgxYphNWohtVohVapAhcsiZWpDhZpS1SpwJipQFkqwFqrQlnqBdnpwJzrQZ4qhZ3qQFlsQFssgdqtgFztAF6tQN1ugF7ugt4txd5txdqsyZnqDhnqSh4qDZ2qClrtTZstCh4uDh3t0lWj01tk3J0i0Vcp1Zbqkhlq1dlrFtpskh5t1d1tktzq2VrtGhxs2NajwV7ww90wit6wkt5woV6k8d7iQKDtAGDvQKKvQqHuRaHuQaUvBeUvA+GqyeFuTaEui2JrTCVmXWIjlCOsmyRs1qkpQKFwQGMwwiKxheIxAGSxgGVyQCYygmWxhWWxAOW0wuQ0yWGxDKTxgOo1wqw0ySu1VOXyGqYx1Gq0HGr0nG56VKz5y7M2xrH3VHV2m7U2HXJ8Wzf5VHJnI6OkK6XjbOml5GVqZinsKizua+vr6Wcqsq3sNSmmdLFuunNu4e42pCv0K+3yYy655ym2NS5yI7N2LbH0YnF6ZbG6YjK9pLT+LfW+qzO8pXo9rPw+pHl3MfHyNbKx8rU2dfX2dHP0OnW0fTl2tjc48fY7+bd5Nvj6Mj7/dn8/tHq+Ofn6fn16+nt8uP+/+v3+vT19PT8/fv9/fj49vTt7Nbi3a3IsiH+EUNyZWF0ZWQgd2l0aCBHSU1QACwAAAAAyAAnAQAI/gBXCBxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatyIcZ/HjyBDihxJsqTJkyhTqlzJsqXLlyIJwpxJs6bNmzhzkpSps6fPn0CDouQptKjRo0hVEt3HsanTp1CjFgS5VKrVq1izIqQ6kKvWr2DDdvxYVazZs2gTel2xNq3bt1/XtoVLt65TuWTt6t2bEa9HvoADR/TLVLDhwwcJI168WDHjx4EdQ55sVzLly24tY94sVjPnz1k9gx4dVTTp0xxNo159UTXr1xJdw57dUDbt21vzCpyLu7da3WyB+x6eGDhv4shtI7+tfPns5s5fQ4++ejr109avj86u/TP37pu//oO/LH785PLmH6NP39i4cPas18M3LH9+ZPd/7UvHX1h/df7+xQdggKjVR2BdBh4IV4IKZjZgg949CGF4Ek5IXoUWnodhhuptyGF7+e323ocg9hdciA7uh6CHYR1HIYppMUhRTKTR6CCKLmq1E2g7xshiaCVF2ONZMkI0FGZHEvmjVUpR1qRZRT70JGNTdrbkVVXSl9KNJuYIZJJagqkkjiO2uGWYJy145Zdp3icmWlFOlCVdc47ZZZlQnlmZnmqSCSOXJu35JpdlrThonof66KeJdPJpZ6B7xdmao2YmSmhXeAIaJKJt8iXpWJaWRqmgd/5JKqQ6jkpqoYDV+ZSr/oaWyqinqjYFa6ysutkpVLfiiqmptIZqUa++ighssLtuRGyxJ84q2LJS1trqmqdu2pe00y6qobC1YZutrE56uxC0en0qFblTifttrh1yaxC65VL7LaoOwRuvti8mq5C994LLGbH89stuuKEGLPCvzhKsL8L0/ivvYXMaHOnDEDsq8cT41qjnxRj7i92WHHc8sJA27ZdxgSWb7PF/Mz1HMWQtu3yygC0x9/K2IaM5Msrqkrzzxz07PDPNOT97c7ss2Tw00C7RZi6cNMm8MtMxE/0zkjipfLXCgRbNrJc4o+p1n1MLnezYlxqbMNfWLtWw2VuX+DbDbcONMI/Yos1p/txozv1u0Lryravfxblr9NJUAq53XEeTTfi+gB+s9oWG/1255M2yPaSckTeK+OELx9b5W0/bOnrhoYMuuON1g5r6unfL3fq1l6edOWKLL/5q42Dp3uzjq8YOOvAa+a4s72wSf3ztVn7O+uZYnp6q85pCj5Xxk1IPNfPFSx+99pwqf67344Nf6evTo2/n6snPHr77ipYdv/jp058++0ySvzv3opp/vf68AmD3/Jc//rXPensT3vbURzoBZk9+vXNgARn4PQjWD37Isl8ACXgXCR5wJPHD3/Io2DENmo6DqTFgA0m4Pwv+D4OyC0kIFdg8G5lNhjOc3PyOpbkVurB+/izjIeNQuEGTee6HcXnO1zJFosDRsIm4Qx4UayjCKS6wilZMoA6zWDEicpGKT/yiyMIoxuBtsYzIwiIaX4jENa6PjG60HdjiCMYz0pFsarxjC/OoxxO2sY9s4iMgB/jHQU5QkIZ8ICITWZHSMTI3Xnwk7QopST8uspJGkiImRRfJTc5Ik56MVidDORhQkpIhjgxlKj1pHRBajoeuLGXbYom6Y9ESlTZ0m/1aecvfQRKBv5llLnW5tl7WcnMrySQHoYdDYgLzlbREoDHVxsTf0SuZoqSkNYXTTGq6a1fWk+Yzk0Y3GKZrmchsSy6HOS7ehHOa8LtlN7s5LIpdkzCm/mJnMPOZTniK00X8WZsstdmpeQJ0jgw7JjffSRZ6UhOVbiMk+wrqFX1aM5vOEtvsZOhQi/5SoMokKFVo1EyHnlOIEYVmSTeqm7mYtJ2X42VecLhSJr60ljjl6EhdWlF1ItSZHkXdRLkSk5oK8abQzGnXeNpSny40moqzZ08bOtWj/tSkNN1RR6vKKHoKM6ZSbaq1kOrLermTqFp1KowM+lQbkjWbQw2oUUH61oQm1Zv98apaZdXVIdW1W+iUK1eL+deynjSvNtIrn/TJVpSaNbBr9etBq5nSw1bWsNu8Z5kaC1K4wvGjKl0UP3+KWbs+1LSZ/eqIOCvRz+L0sG2N/ixpS3tamIpWTPLEZ2vtiMvVrpOcvZUsZee6T76CCZuPFalvt9ozcM6RuKAFKlSDJlNgMVaDzh0uV4ur0OlWrroJ8+g0bevdzpaVrC/953dNeUrIjbK9gNUmfDkp3/mG9JL2PSl+86vA2fI3ufv97yo3OWBMFriSB5Zkgh+5YEZOx5hIxapFs+tYYhZXvZ1F7itXB+H0SvimFDavhT/6trdqWL+uhW14j+NhEGu2wuW8cMNM7CrosHSzZ/WnakWMV+sCl7ahBaaNGfoedsLwwzBObXR1edkl3zfF5fRxkVn8TCAXVsmvtSxqnexZ3oIWybMCM5C3XNvgMkXMdy0z/pcBDGVfgtm4Ss0UmuN75hyPtq/VvHJ/KXu7PmtZzcLL0ZyDG0bmyhalsFIOdP9s5e2uecxpNrS+aGwpRTua0XN28XIrvOgoGxlsiV5Tp1Pa4hBp+s4iHnVqc5tnadlGsagGdGlLndHn7lXFL86wf/0M6lvfddBjBjaXYV3rS3OXvls7sadXrCphd5fVUjZ1r/mMYi9Lt8NEHpWzcb3jJVM6yXu2qrJX/exsZ1nGufb2tMF9Ri/VrLskXti2r+1Wphr70YT+7KmLPe+51htkk5W2hrE57nbLOeD8tjNhxSrcoex72b89U8F5fXA80ZrZthwsZ5dqcY0zs0kTVw16pxWecPL2WLB5Q2voCF5j9v7X4Ox+uW0DzN8GJ9LmhsT5IHUOSJ730ed6BPodhU5HosfR6G5E+hqVjkaml9HpYoT6F6XORapn0epWxPoUtQ5FrjfR6yQC+4fEziGyZ8jsFkL7hNQOIbY3yO0KgvuB5E4gugfI7v7Bu370bh++z8fv8AE8e/CZlMIb/vA9oTfiF8/4xv/b8ZCPfOQVL/nKW94nMs/8awICADs="
        self.no_img = PhotoImage(data=img_data)

        self.preview_img = Label(self.frame_details, image=self.no_img)
        self.preview_img.image = self.no_img
        self.preview_img.pack(fill=BOTH, anchor=N,expand=1, pady=5)

        self.text_info = ScrolledText(self.frame_details, font=f_2, bg=c_accent, height=10, width=50, wrap="no")
        text = "\n  Titel:\n\n  Land/Sprache:\n\n  Verlag:\n\n  ISBN:"
        self.text_info.insert(END, text)
        self.text_info.configure(state=DISABLED)
        self.text_info.vbar.configure(orient=HORIZONTAL, command=self.text_info.xview)
        self.text_info["xscrollcommand"] = self.text_info.vbar.set
        self.text_info.pack(fill=BOTH, expand=1, anchor=S)
        self.text_info.vbar.pack(side=BOTTOM, fill=X)

        # Frame details buttons

        self.button_data = Button(self.frame_details_buttons, text="Daten online beziehen", font=f_b2, bg=c_accent, command=lambda :self.btn_callback("load_data"), state=DISABLED)
        self.button_data.pack(side=LEFT, fill=X, expand=1, pady=(8,0))

        self.button_reset = Button(self.frame_details_buttons, text="Auswahl zurücksetzen", font=f_b2, bg=c_accent, command=lambda :self.btn_callback("reset"),state=DISABLED)
        self.button_reset.pack(side=LEFT, fill=X, expand=1, padx=(15,0), pady=(8,0))

    def btn_callback(self, i):
        if i == "exit":
            self.leave_program()
        elif i == "about":
            self.about()
        elif i == "del":
            self.del_item()
        elif i == "isbn_new":
            self.prepare_isbn_from_input()
        elif i == "list":
            self.selection_handler()
        elif i == "reset":
            self.reset()
        elif i == "more":
            self.more_info()
        elif i == "load_data":
            self.load_data_launcher()

    def about(self):
        small_gui.SmallGui(self,about_text,"Über den ISBN Checker")

    def leave_program(self):
        if os.path.exists("saved"):
            x = messagebox.askyesnocancel("Cache leeren", "Soll der Zwischenspeicher (heruntergeladene Bilder/Texte) geleert werden?", default=messagebox.NO)
            if x == True:
                shutil.rmtree("saved", ignore_errors=True)
            elif x == None:
                return
        self.destroy()

    def del_item(self):
        self.list_isbn.delete(ACTIVE)
        self.selection_handler()

    def reset(self):
        self.list_isbn.selection_clear(ACTIVE)
        self.selection_handler()

    def more_info(self):
        x = self.list_isbn.curselection()
        if len(x) >= 1:
            isbn = self.list_isbn.get(x)[:13]
            small_gui.SmallGui(self, isbnchecker.moreinfo(isbn), "Infos zu "+str(isbn))

    def prepare_isbn_from_input(self):
        if self.isbn.get():
            x = isbnchecker.prepisbn(self.isbn.get().strip())

            if not x:
                if messagebox.askokcancel("Eingabefehler", "Die ISBN-Nummer wurde im falschen Format eingetragen. Hilfe öffnen?", icon=messagebox.ERROR, default=messagebox.CANCEL):
                    small_gui.SmallGui(self, help_text, "Eingabehilfe")
                else: return
            else:
                self.new_list_entry(x)
                self.isbn.set("")

    def new_list_entry(self, isbn_parsed):
        if isbnchecker.checkisbn(isbn_parsed):
            self.list_isbn.insert(END, str(isbn_parsed) + ": Gültig")
            self.list_isbn.itemconfig(self.list_isbn.index(END) - 1, {'bg': 'lightgreen'})
        else:
            self.list_isbn.insert(END, str(isbn_parsed) + ": Ungültig")
            self.list_isbn.itemconfig(self.list_isbn.index(END) - 1, {'bg': '#ff7a7a'})

    def selection_handler(self):
        if len(self.list_isbn.curselection()) == 0:
            self.selection = None
            self.load_default_details()
            self.button_del["state"] = DISABLED
            self.button_data["state"] = DISABLED
            self.button_reset["state"] = DISABLED
            return
        else:
            self.selection = self.list_isbn.curselection()[0]
            self.selected_isbn = self.list_isbn.get(self.selection)[:13]
            self.button_del["state"] = NORMAL
            self.button_data["state"] = NORMAL
            self.button_reset["state"] = NORMAL
            self.load_details(self.selected_isbn)

    def load_details(self,isbn):
        try:
            self.parse_txtfile("saved\\"+str(self.selected_isbn)+".txt")

            t = "\n  Titel: "+self.info["title"]+"\n\n  Land/Sprache: "+self.info["country"]+"\n\n  Verlag: "+self.info["publisher"]+"\n\n  ISBN: "+str(isbn)
            self.text_info["state"]=NORMAL
            self.text_info.delete(1.0,END)
            self.text_info.insert(END,t)
            self.text_info["state"] = DISABLED
            self.label_titel["text"] = self.info["title"]

            if self.info["image"]:
                img = PhotoImage(file="saved\\"+str(isbn)+".gif")
                self.preview_img.configure(image=img)
                self.preview_img.image = img
            else:
                self.preview_img.configure(image=self.no_img)
                self.preview_img.image = self.no_img
        except: self.load_isbn_only(isbn)

    def load_default_details(self):
        self.label_titel["text"] = "Kein Titel verfügbar"
        self.preview_img.configure(image=self.no_img)
        self.preview_img.image = self.no_img
        text = "\n  Titel:\n\n  Land/Sprache:\n\n  Verlag:\n\n  ISBN:"
        self.text_info["state"] = NORMAL
        self.text_info.delete(1.0, END)
        self.text_info.insert(END, text)
        self.text_info["state"] = DISABLED

    def load_isbn_only(self, isbn):
        self.load_default_details()
        text = "\n  Titel:\n\n  Land/Sprache:\n\n  Verlag:\n\n  ISBN: "+str(isbn)
        self.text_info["state"] = NORMAL
        self.text_info.delete(1.0, END)
        self.text_info.insert(END, text)
        self.text_info["state"] = DISABLED

    def load_data_launcher(self):
        grabber_gui.DatagrabberGui(self, "Daten laden", self.list_isbn.get(self.selection)[:13])
        self.selection_handler()

    def load_examples(self):
        for i in [9783898186223,9783060400133,9783766146410,9783898185257]:
            self.new_list_entry(i)

    def parse_txtfile(self, path):
        x = "self.info = {"
        with open(path,"r") as file:
            for i in file.readlines():
                x += i[:-1]+","
            x = x[:-1]+"}"
            exec(x)















