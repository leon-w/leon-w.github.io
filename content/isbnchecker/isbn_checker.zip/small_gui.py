#---------------------------
# small_gui.py v1 (Py 3.5)
#---------------------------

from tkinter import *


f = ("Helvetica", 10, "bold")
f_mono = ("Consolas",13, "bold")

class SmallGui(Toplevel):
    def __init__(self, parent, text, title):
        Toplevel.__init__(self, parent)
        self.parent = parent

        self.title(title)
        self.focus_force()
        self.bind("<Escape>", lambda i: self.exit())

        self.frame = Frame(self, padx=8, pady=8)
        self.frame.pack(fill=BOTH, expand=1)

        self.labelframe = LabelFrame(self.frame, text=title, padx=8, pady=8, font=f)
        self.labelframe.pack(fill=BOTH, expand=1)

        self.text = Message(self.labelframe, text=text, font=f_mono)
        self.text.bind("<Configure>", lambda e: self.text.configure(width=e.width - 10))
        self.text.pack(fill=BOTH, expand=1)

        self.button_destroy = Button(self.labelframe, text="Fesnter schließen", command=self.exit, bg="lightgray", font=f)
        self.button_destroy.pack(fill=X)

    def exit(self):
        self.destroy()


