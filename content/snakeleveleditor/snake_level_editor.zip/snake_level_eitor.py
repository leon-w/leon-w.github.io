# -*- coding: cp1252 -*-
#Level_Editor.py v0.6


#Variablen

letter_apple = "A"
letter_wall =  "H"
letter_snake = "S"
letter_exit =  "E"
letter_emty =  " "

liste = []
platzhalter = []
selected = "black"
graph_status = 0
breite = 0
size=20

#Importe / Versionscheck

try:
    from Tkinter import *
    import time, tkMessageBox, os
    version = 2
except:
    from tkinter import *
    from tkinter import messagebox
    import time, os
    version = 3

#Definitionen

def new_level_window():
    
    def ok():
        
        if name.get() == "":
            log("Ungueltiger Dateiname!")
            if version == 2:
                tkMessageBox.showerror("Ung�ltiger Dateiname!","Ein g�ltiger Dateiname muss angegeben sein!")
            else:
                messagebox.showerror(title="Ung�ltiger Dateiname!",message="Ein g�ltiger Dateiname muss angegeben sein!")
        else:
            log("Dateiname ist gueltig!")
            weiter_var = 0
            try:
                int(x.get())
                int(y.get())
                weiter_var = 1
            except:
                log("Falsche Angaben bei X und/oder Y!")
                if version == 2:
                    tkMessageBox.showerror("Ung�ltige Werte!","F�r X und Y d�rfen nur Zahlen angegben werden!")
                else:
                    messagebox.showerror(title="Ung�ltige Werte!",message="F�r X und Y d�rfen nur Zahlen angegben werden!")
            if weiter_var == 1:
                weiter_var = 0
                log("X/Y Angaben sind gueltig!")

                global name_var
                name_var = str(name.get())
                global x_var
                x_var = int(x.get())
                if x_var > 50:
                    x_var = 50
                else:
                    pass   
                global y_var
                y_var = int(y.get())
                if y_var > 40:
                    y_var = 40
                else:
                    pass
                
                root.destroy()
                main_window()
            else:
                pass

    root =Tk()
    root.title("Neues Level")
    root.geometry("260x95")
    root.resizable(width=False, height=False)
    root.focus_force()

    Label(root, text=("Neues Level erstellen"),font=("Helvetica",10, "bold")).grid(columnspan=2, sticky=W)
    Label(root, text="Name:     ").grid(row=1, sticky=W)
    Label(root, text="X: ").grid(row=2, sticky=W)
    Label(root, text="Y: ").grid(row=3, sticky=W)

    name = Entry(root)
    name.grid(row=1, column=1, sticky=W)
    name.insert(END,"level1")

    x = Spinbox(root, from_=0, to=50)
    x.grid(row=2, column=1)
    x.insert(0,"5")

    y = Spinbox(root, from_=0, to=40)
    y.grid(row=3, column=1)
    y.insert(0,"3")

    ok = Button(root, text="OK",width=5, command=ok)
    ok.grid(row=1, column=3, rowspan= 3, sticky=W+E+N+S, padx=15, pady=0)

    log("new_level_window wurde erfolgreich erstellt")
    root.mainloop()



def main_window():

    def buttons(hoch,breit):
        for i in range(hoch):
            liste.append([])
            platzhalter.append([])
            for j in range(breit):
                platzhalter[i].append(Frame(right,width=size,height=size))
                f = platzhalter[i][j]
                liste[i].append(Button(f,bg="white",bd=breite,command = lambda i=i, j=j: color(i,j)))
                b = liste[i][j]
                f.rowconfigure(0, weight = 1)
                f.columnconfigure(0, weight = 1)
                f.grid_propagate(0)
                f.grid(row = i, column = j)
                b.grid(sticky = "NWSE")

    def tool(tool):
        rahmen_label.configure(text=(str(name_var)+" | "+str(x_var)+"x"+str(y_var))+" | Tool: "+str(tool))
        
    
    def graph():        
        stat = 0 
        for i in range(y_var):
            for j in range(x_var):
                now = liste[i][j]
                cox = now.cget("bg")
                if cox == "orange":
                    stat += 1
                    if stat == 1:
                        x1 = j
                        y1 = i
                        now.configure(bg="white")
                    if stat == 2:
                        x2 = j
                        y2 = i
                        if x1 == x2:
                            now.configure(bg="white")
                            for i in range(y_var):
                                for j in range(x_var):
                                    now = liste[i][j]
                                    if i+1 > y1 and i-1 < y2 and j == x1:
                                        now.configure(bg="black")
                            log("y-Graph wird gezeichnet")
                            break
                        elif y1 == y2:
                            now.configure(bg="white")
                            for i in range(y_var):
                                for j in range(x_var):
                                    now = liste[i][j]
                                    if j+1 > x1 and j-1 < x2 and i == y1:
                                        now.configure(bg="black")
                            log("x-Graph wird gezeichnet")
                            break
                        else:
                            now.configure(bg="white")
                else:
                    pass
                            
    def color(x,y):
        now = liste[x][y]
        co = now.cget("bg")
        if co == "white":            
            if selected == "green":
                for i in range(y_var):
                    for j in range(x_var):
                        nowx = liste[i][j]
                        cox = nowx.cget("bg")
                        if cox == "green":
                            nowx.configure(bg="white")
                        else:
                            pass
            if selected == "blue":
                for i in range(y_var):
                    for j in range(x_var):
                        nowx = liste[i][j]
                        cox = nowx.cget("bg")
                        if cox == "blue":
                            nowx.configure(bg="white")
                        else:
                            pass
            now.configure(bg=selected)

            if selected == "orange":
                global graph_status
                graph_status += 1
                if graph_status == 2:
                    graph_status = 0
                    now.configure(bg=selected)
                    graph()
                else:
                    now.configure(bg=selected)
        else:
            now.configure(bg="white")

    global export
    def export(extra,text):
        desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
        dateiname = desktop+"\\"+str(name_var)+".txt"
        datei = open(dateiname, "w")
        for p in range(y_var):
            for q in range(x_var):
                nowx = liste[p][q]
                cox = nowx.cget("bg")
                if cox == "red":
                    datei.write(letter_apple)
                elif cox == "green":
                    datei.write(letter_snake)
                elif cox == "blue":
                    datei.write(letter_exit)
                elif cox == "black":
                    datei.write(letter_wall)
                else:
                    datei.write(letter_emty)
            datei.write("\n")
        if extra == 1:
            datei.write(text)
        else:
            pass
        datei.close()
        log(name_var+".txt wurde erfolgreich exportiert")
        if version == 2:
            tkMessageBox.showinfo("Export abgeschlossen", dateiname+" wurde erfolgreich exportiert!")
        else:
            messagebox.showinfo(title="Export abgeschlossen",message=dateiname+" wurde erfolgreich exportiert!")

    def rahmen():
        for i in range(y_var):
            for j in range(x_var):
                if j == 0 or j == x_var-1 or i == 0 or i == y_var-1:
                    now = liste[i][j]
                    now.configure(bg="black")


    def clear():
        for i in range(y_var):
            for j in range(x_var):
                now = liste[i][j]
                cox = now.cget("bg")
                if cox != "white":
                    now.configure(bg="white")

    
    root = Tk()
    root.focus_force()
    root.title(str(name_var)+" - "+str(x_var)+"x"+str(y_var))

    def exportnormal():
        export(0,None)

    menubar = Menu(root)
    dateimenu = Menu(menubar, tearoff=0)
    dateimenu.add_command(label="Schnellexport", command=exportnormal)
    dateimenu.add_command(label="Export", command=export_window)
    dateimenu.add_separator()
    dateimenu.add_command(label="Schlie�en", command=root.destroy)
    menubar.add_cascade(label="Datei", menu=dateimenu)

    def wand():
        global selected
        selected = "black"
        tool("Wand")
    def apfel():
        global selected
        selected = "red"
        tool("Apfel")        
    def schlange():
        global selected
        selected = "green"
        tool("Schlange")
    def ausgang():
        global selected
        selected = "blue"
        tool("Ausgang")
    def graph_col():
        global selected
        selected = "orange"
        tool("Graph")

   
    rahmen_label = LabelFrame(root,highlightthickness=8,bd=2,padx=8,pady=8,font=("Helvetica",10, "bold"),cursor="crosshair")
    rahmen_label.pack(fill="both", expand="yes")
    tool("Wand")
    right = Frame(rahmen_label)
    right.pack(side = "right")

    blockmenu = Menu(menubar, tearoff=0)
    blockmenu.add_command(label="Wand", command=wand)
    blockmenu.add_command(label="Apfel", command=apfel)
    blockmenu.add_command(label="Schlange", command=schlange)
    blockmenu.add_command(label="Ausgang", command=ausgang)
    menubar.add_cascade(label="Block", menu=blockmenu)

    hilfemenu = Menu(menubar, tearoff=0)
    hilfemenu.add_command(label="Rahmen", command=rahmen)
    hilfemenu.add_command(label="Graph", command=graph_col)
    hilfemenu.add_separator()
    hilfemenu.add_command(label="Leeren", command=clear)
    menubar.add_cascade(label="Tools", menu=hilfemenu)

    einstellungenmenu = Menu(menubar, tearoff=0)
    einstellungenmenu.add_command(label="Einstellungen", command=settings_window)
    einstellungenmenu.add_command(label="Exporteinstellungen", command=export_settings_window)
    einstellungenmenu.add_separator()
    einstellungenmenu.add_command(label="Tutorial", command=hilfe_window)
    menubar.add_cascade(label="Einstellungen", menu=einstellungenmenu)

    root.config(menu=menubar)
    buttons(y_var,x_var)
    
    log("main_window wurde erfolgreich erstellt")
    root.resizable(0,0)
    root.mainloop()

def export_settings_window():

    def ok():
        global letter_wall
        letter_wall = str(wand.get())
        global letter_apple
        letter_apple = str(apfel.get())
        global letter_snake
        letter_snake = str(schlange.get())
        global letter_exit
        letter_exit = str(ausgang.get())
        root.destroy()
        log("neue Einstellungen gesetzt")

    root = Tk()
    root.focus_force()
    root.title("Exporteinstellungen")
    root.geometry("250x90")

    Label(root, text="Wand: ").grid(row=1, column=0, sticky=W)
    Label(root, text="Apfel: ").grid(row=2, column=0, sticky=W)
    Label(root, text="Schlange: ").grid(row=3, column=0, sticky=W)
    Label(root, text="Ausgang:        ").grid(row=4, column=0, sticky=W)

    wand = Entry(root, width = 15)
    wand.grid(row=1, column=1)
    wand.insert(END,letter_wall) 
    apfel = Entry(root, width = 15)
    apfel.grid(row=2, column=1)
    apfel.insert(END,letter_apple) 
    schlange = Entry(root, width = 15)
    schlange.grid(row=3, column=1)
    schlange.insert(END,letter_snake)
    ausgang = Entry(root, width = 15)
    ausgang.grid(row=4, column=1)
    ausgang.insert(END,letter_exit)
    ok = Button(root, text="OK",width=5, height=4, command=ok)
    ok.grid(row=1, column=2, rowspan= 10, sticky=W+E+N+S, padx=15, pady=5)
    
    root.resizable(0,0)
    log("Einstellungsfenster geoeffnet")
    root.mainloop()

def settings_window():

        def ok():
            global selected
            for i in range(y_var):
                for j in range(x_var):
                    global breite
                    breite = check.get()
                    global size
                    size = pixel_size.get()
                    now = liste[i][j]
                    now.configure(bd=breite)
                    now = platzhalter[i][j]
                    now.configure(width=size,height=size)
            log("Einstellungen geandert")

        root = Tk()
        root.focus_force()
        root.title("Einstellungen")
        root.resizable(0,0)

        label_frame_set = LabelFrame(root,text="Gitterbreite:",highlightthickness=8,bd=2,pady=8,padx=8)
        label_frame_set.pack(fill="both", expand="yes")
        check = Scale(label_frame_set, from_=0, to=3, orient=HORIZONTAL,label="Gitter",sliderlength="50")
        check.grid(row=0, column=1,sticky=W)
        check.set(breite)
        pixel_size = Scale(label_frame_set, from_=10, to=30, orient=HORIZONTAL,label="Gr��e",sliderlength="50")
        pixel_size.grid(row=1, column=1,sticky=W)
        pixel_size.set(size)        
        ok_gitter = Button(label_frame_set, text='Ok', width= 23,command=ok)
        ok_gitter.grid(row=5, column=1,sticky=W)
        
        
        root.mainloop()    

def hilfe_window():
    root = Tk()
    
    text = """
Ein Klick auf einen wei�en Pixel f�rbt diesen mit dem ausgew�hlten Tool. \n
Ein Klick auf einen farbigen Pixel f�rbt diesen wei�. \n
Ist das Tool "Graph" ausgew�hlt werden zwei gesetzte Punkte mit gleicher X- oder Y-Koordinate verbunden. \n
"Export" erstellt eine Textdatei im gleichen Verzeichnis wie der Editor.
    """

    label_frame_set = LabelFrame(root,text="Hilfe",highlightthickness=4,bd=2,pady=4,padx=4)
    label_frame_set.pack(fill="both")
    label = Message(label_frame_set, text=text, relief=RAISED)
    label.pack(fill="both")
    root.resizable(0,0)
    root.title("Hilfe")
    root.mainloop()

def export_window():

    def ok():
        extralines = T.get(1.0,END)        
        export(1,extralines)
        root.destroy()
        
    root = Tk()
    root.title("Export")
    root.geometry("260x140")
    root.resizable(width=False, height=False)
    labelframe = LabelFrame(root,text="Export",bd=2,pady=4,padx=4)
    labelframe.pack(fill="both")
    root.focus_force()
    S = Scrollbar(labelframe)
    T = Text(labelframe, height=5, width=50)
    S.pack(side=RIGHT, fill=Y)
    T.pack(side=LEFT, fill=Y)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    text = ""
    T.insert(END, text)

    ok = Button(root, text="Export",width=5, command=ok)
    ok.pack()

    
    root.mainloop()
    


def log(text):
    log = "["+time.asctime(time.localtime())+"]   "+str(text)
    print(log)


#Code  

new_level_window()


