from PyQt4.QtGui import *
from PyQt4 import uic
import sys, os, math

if getattr(sys, "frozen", False):
    os.chdir(sys._MEIPASS)

Ui_Window, QtBaseClass = uic.loadUiType("window.ui")


class SubnetCalcApp(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.qss_stylesheet = open("style.qss").read()
        self.setStyleSheet(self.qss_stylesheet)
        self.ui = Ui_Window()
        self.ui.setupUi(self)
        self.combos = [self.ui.combobox_netmaskbits,
                       self.ui.combobox_hosts,
                       self.ui.combobox_subnetmask,
                       self.ui.combobox_subnetbits,
                       self.ui.combobox_subnets]
        for i in self.combos:
            i.activated.connect(lambda index=i.currentIndex(): self.update_combos(index))
        self.ui.radiobutton_a.toggled.connect(lambda: self.set_network_class("a"))
        self.ui.radiobutton_b.toggled.connect(lambda: self.set_network_class("b"))
        self.ui.radiobutton_c.toggled.connect(lambda: self.set_network_class("c"))
        self.set_network_class("a")
        self.ui.lineedit_ip.editingFinished.connect(lambda: self.check_ip(self.ui.lineedit_ip.text()))

    def set_network_class(self, netclass):
        self.network_class = netclass
        if self.network_class == "a":
            self.first_octet_range = range(1,127)
            self.ui.lineedit_ip.setText("10.0.0.1")
            self.pre = 8
        elif self.network_class == "b":
            self.first_octet_range = range(128, 192)
            self.ui.lineedit_ip.setText("172.16.0.1")
            self.pre = 16
        elif self.network_class == "c":
            self.first_octet_range = range(192, 223)
            self.ui.lineedit_ip.setText("192.168.0.1")
            self.pre = 24
        self.ui.label_firstoctetrange.setText("%d - %d" % (self.first_octet_range[0], self.first_octet_range[-1]))
        self.reset()

    def check_ip(self, ip):
        def wrong():
            self.set_network_class(self.network_class)
            QMessageBox.critical(self, "Fehlerhafte IP", "IP ist für die ausgewählte Netzklasse ungültig!")
        octets = ip.split(".")
        try:
            octets = [int(x) for x in octets if int(x) < 256]
            if octets[0] not in self.first_octet_range or len(octets) != 4:
                wrong()
            else:
                self.update_labels()
        except:
            wrong()

    def update_labels(self):
        x = int(math.log(int(self.ui.combobox_hosts.currentText())+2, 2))
        t = "0"*(32-self.pre-x)+"1"*(x-1)+"0"
        chunks = [str(int(t[x:x + 8], 2)) for x in range(0, len(t), 8)]
        l = ".".join(chunks)
        chunks[-1] = str(int(chunks[-1])+1)
        l_broadcast = ".".join(chunks)
        ip = self.ui.lineedit_ip.text().split(".")
        r = ""
        for i in range(int(self.pre/8)):
            r += ip[i]+"."
        _from = r+"0."*(int((32-self.pre)/8)-1)+"1"
        _to = r+l
        self.ui.label_hostrange.setText(_from + "   -   " + _to)
        self.ui.label_broadcast.setText(r+l_broadcast)
        self.visualize()

    def update_combos(self, combo_index):
        for index, i in enumerate(self.combos):
            self.combos[index].setCurrentIndex(combo_index)
        self.update_labels()

    def visualize(self):
        html = """
        <html><head/><body>
        <p align="center"><span style=" font-size:11pt; color:#aa0000;">{}</span><span style=" font-size:11pt; color:#d54700;">{}</span\><span style=" font-size:11pt; color:#0aaa17;">{}</span></p>
        </body></html>
        """
        netclass = "1" * (int(self.pre/8)-1) + "0" + "n" * (8 - int(self.pre/8)) + "." + "nnnnnnnn." * (int(self.pre/8)-1)
        rest = "s" * int(self.combos[3].currentText()) + "h" * (32 - self.pre - int(self.combos[3].currentText()))
        rest = ".".join([rest[x:x + 8] for x in range(0, len(rest), 8)])
        x = rest.split("sh")
        if x == [rest]:
            x = rest.split("s.h")
            if len(x) > 1:
                subnet = x[0] + "s."
                hosts = "h" + x[1]
            else:
                subnet = ""
                hosts = x[0]
        else:
            subnet = x[0]+"s"
            hosts = "h"+x[1]
        self.ui.textedit_visual.setHtml(html.format(netclass, subnet, hosts))

    def generate_mask(self, bits):
        mask = "1" * bits + "0" * (32 - bits)
        chunks = [str(int(mask[x:x + 8], 2)) for x in range(0, len(mask), 8)]
        return ".".join(chunks)

    def reset(self):
        for i in self.combos:
            i.clear()
        for i in range(0, 31-self.pre):
            self.ui.combobox_subnetbits.addItem(str(i), str(i))
            self.ui.combobox_netmaskbits.addItem(str(i+self.pre), str(i))
            self.ui.combobox_subnets.addItem(str(2**i), str(i))
            self.ui.combobox_hosts.addItem(str(((2)**((30-self.pre-i)+2))-2), str(i))
            self.ui.combobox_subnetmask.addItem(self.generate_mask(i+self.pre), str(i))
        self.update_labels()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SubnetCalcApp()
    window.show()
    sys.exit(app.exec_())